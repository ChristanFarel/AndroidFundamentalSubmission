package com.example.sub1githubuser

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sub1githubuser.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var rcyUser: RecyclerView
    private val list = ArrayList<GHuser>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        supportActionBar?.hide()

        rcyUser = findViewById(R.id.rcyUser)
        rcyUser.setHasFixedSize(true)


        list.addAll(listUser)
        showRecyclerList()
    }

    private val listUser: ArrayList<GHuser>
        get() {
            val dataNama = resources.getStringArray(R.array.data_nama)
            val datausername = resources.getStringArray(R.array.data_username)
            val dataFollower = resources.getStringArray(R.array.data_follower)
            val dataFollowing = resources.getStringArray(R.array.data_following)
            val dataFoto = resources.obtainTypedArray(R.array.data_foto)
            val dataLoc = resources.getStringArray(R.array.data_location)
            val dataRepo = resources.getStringArray(R.array.data_repo)
            val dataCompany = resources.getStringArray(R.array.data_company)

            val listUser = ArrayList<GHuser>()
            for (i in dataNama.indices) {
                val user = GHuser(dataNama[i],datausername[i],dataFoto.getResourceId(i,0),dataFollower[i],dataFollowing[i],dataCompany[i], dataLoc[i], dataRepo[i])
                listUser.add(user)
            }
            return listUser
        }

    private  fun showRecyclerList(){
        rcyUser.layoutManager = LinearLayoutManager(this)
        val listUserAdapter = ListGHuserAdapter(list)
        rcyUser.adapter  = listUserAdapter

        listUserAdapter.setOnItemClickCallback(object : ListGHuserAdapter.OnItemClickCallback {
            override fun onItemClicked(data: GHuser) {
                showSelectedUser(data)
            }
        })
    }

    private fun showSelectedUser(user: GHuser) {
        val semua = GHuser(user.nama,
            user.username,
            user.foto,
            user.follower,
            user.following,
            user.company,
            user.location,
            user.repo
            )
        val Intent = Intent(this, DetailUser::class.java)

        Intent.putExtra("All", semua)
        startActivity(Intent)
    }
}